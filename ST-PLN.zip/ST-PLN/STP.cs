using System;
using System.Threading;
using Robotics.API;
using Robotics.PacIto;

namespace ST_PLN
{
	/// <summary>
	/// Implements the Simple Task Planner
	/// </summary>
	public class STP
	{
		#region Variables

		/// <summary>
		/// Connection manager used to manage connections
		/// </summary>
		private ConnectionManager cnnMan;
		/// <summary>
		/// Command manager used to manage commands
		/// </summary>
		private PacItoCommandManager cmdMan;

		/// <summary>
		/// Executer for the find_human command
		/// </summary>
		private CommandExecuter findHuman;
		/// <summary>
		/// Executer for the remember_human command
		/// </summary>
		private CommandExecuter rememberHuman;
		/// <summary>
		/// Executer for the find_object command
		/// </summary>
		private CommandExecuter findObject;
		/// <summary>
		/// Executer for the train_object command
		/// </summary>
		private CommandExecuter trainObject;

		/// <summary>
		/// Indicates that the STP is running and allow to terminate its execution con CTRL+C
		/// </summary>
		private bool running;
		
		#endregion

		#region Constructors

		public STP()
		{
			cmdMan = new PacItoCommandManager();
			//cnnMan = new ConnectionManager(2400, 2300, System.Net.IPAddress.Parse("127.0.0.1"), cmdMan);
			cnnMan = new ConnectionManager(2400, cmdMan);

			// Create the executers which will handle and execute incomming commands
			findHuman = new FindHumanCommandExecuter();
			rememberHuman = new RememberHumanCommandExecuter();
			findObject = new FindObjectCommandExecuter();

			// Create the event handlers
			cnnMan.ClientConnected += new System.Net.Sockets.TcpClientConnectedEventHandler(cnnMan_ClientConnected);
			cnnMan.ClientDisconnected += new System.Net.Sockets.TcpClientDisconnectedEventHandler(cnnMan_ClientDisconnected);
			cmdMan.CommandReceived += new CommandReceivedEventHandler(cmdMan_CommandReceived);

			// Add the CommandExecuters to the CommandManager to allow it to execute them
			cmdMan.CommandExecuters.Add(findHuman);
			cmdMan.CommandExecuters.Add(rememberHuman);
			cmdMan.CommandExecuters.Add(findObject);

			Console.CancelKeyPress += new ConsoleCancelEventHandler(Console_CancelKeyPress);
		}

		void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
		{
			running = false;
			Stop();
		}

		#endregion

		#region Methods

		/// <summary>
		/// Starts the SimpleTaskPlanner
		/// </summary>
		public void Run()
		{
			// A command object to typed command injection
			Command command;

			Console.WriteLine("Simple Task Planner");
			Console.WriteLine();
			Console.WriteLine();
			
			// Start connection manager. Socket connections will begin
			cnnMan.Start();
			Console.WriteLine("Connection manager started. TCP Server is running");

			// Start command manager. Command management/redirection will begin
			cmdMan.Start();

			running = true;
			Console.WriteLine("Simple Task Planner Online!");
			Console.WriteLine();
			while (running)
			{
				if (Command.TryParse(Console.ReadLine(), out command))
					cmdMan.BeginCommandExecution(command);
				//System.Threading.Thread.Sleep(100);
			}
		}

		/// <summary>
		/// Stops the SimpleTaskPlanner
		/// </summary>
		public void Stop()
		{
			Console.WriteLine("Stopping Simple Task Planner");
			//if(cmdMan.Started)
			cmdMan.Stop();
			if(cnnMan.Started)
				cnnMan.Stop();
			Console.WriteLine("Done! Simple Task Planner stopped.");
		}

		#region Event handlers

		/// <summary>
		/// Advices of remote client disconnection
		/// </summary>
		/// <param name="ep">Endpoint of remote client</param>
		void cnnMan_ClientDisconnected(System.Net.EndPoint ep)
		{
			string rAddress = "";
			try
			{
				rAddress = " from " + ((System.Net.IPEndPoint)ep).Address.ToString();
			}
			catch{}
			Console.WriteLine("Remote client disconnected" + rAddress);
		}

		/// <summary>
		/// Advices of remote client disconnection
		/// </summary>
		/// <param name="s">Connection socket to remote client</param>
		void cnnMan_ClientConnected(System.Net.Sockets.Socket s)
		{
			Console.WriteLine("Remote client connected from " + ((System.Net.IPEndPoint)s.RemoteEndPoint).Address.ToString());
		}

		/// <summary>
		/// Advices of incomming command
		/// </summary>
		/// <param name="command">The command received</param>
		void cmdMan_CommandReceived(Command command)
		{
			Console.WriteLine("Received command: " + command.ToString());
		}

		#endregion

		#endregion

		#region Static Methods

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main(string[] args)
		{
			STP simpleTaskPlanner = new STP();

			simpleTaskPlanner.Run();
		}

		#endregion
	}
}