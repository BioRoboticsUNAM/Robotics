using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Robotics.API;
using Robotics.PacIto;

namespace ST_PLN
{
	/// <summary>
	/// Represents a CommandExecuter that executed the find_human command
	/// </summary>
	public class FindHumanCommandExecuter : AsyncCommandExecuter
	{
		#region Variables
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of FindHumanCommandExecuter
		/// </summary>
		public FindHumanCommandExecuter()
			: base("find_human") { }

		#endregion

		#region Events
		#endregion

		#region Properties

		public new PacItoCommandManager CommandManager
		{
			get { return (PacItoCommandManager)base.CommandManager; }
		}

		#endregion

		#region Methodos

		protected override Response AsyncTask(Command command)
		{
			// Store head positions
			double[,] headPositions = GetHeadPositions(0.7, 0.4);
			// Store robot turn angles
			double[] angles = new double[]
			{
				0.3926,		// Turn 22.5 degrees left.
				-0.7854		// Return to 0 and turn 22.5 degrees right
			};
			//Retrieve the human name
			string humanName = command.Parameters.Trim();
			// Head position index
			int hix = 0;
			// Robot angle index
			int raix = 0;
			// Flag that indicates if human has been found
			bool found = false;
			// flag that indicates error
			bool error = false;

			// From robot starting position
			Console("Executing find_human");
			do
			{
				// From head startup/last position
				hix = 0;
				do
				{
					// 1. Move the head to the next position (first position center the head).
					if (error &= !CommandManager.RobotHead.LookAt(ref headPositions[hix, 0], ref headPositions[hix, 1]))
					{
						++hix;
						// Stabilization time
						Thread.Sleep(10);
					}
					else break;

					// 2. Send the find human command and wait for response.
					if (found |= CommandManager.RobotPersonFinder.FindHuman(ref humanName))
						break;

				} while (!found && !error && (hix < headPositions.GetLength(0)));
				if (found || error) break;

				// 3. Before turn, reset the face
				error &= !CommandManager.RobotHead.Show("normal");
				// 4. No human found. Moving robot to next angle
				error &= !CommandManager.RobotBase.MoveBase(0, angles[raix++], 5000);
				// 5. All head positions visited. Reset head counter
				hix = 0;

			} while (!found && !error && (raix < angles.Length));

			// 6. On error send failed response
			if (error)
			{
				Console("Error executing find_human");
				return Response.CreateFromCommand(command, false);
			}

			// 7. If no human found send failed response.
			if (!found)
			{
				Console("No human found");
				return Response.CreateFromCommand(command, false);
			}

			// 8. Update and send response
			command.Parameters = humanName;
			return Response.CreateFromCommand(command, true);
		}

		public override void DefaultParameterParser(string[] parameters)
		{
			return;
		}

		/// <summary>
		/// Gets an array of positions the head must move while looking for a human
		/// </summary>
		/// <param name="limit">Max angle to move</param>
		/// <returns>array of positions</returns>
		private double[,] GetHeadPositions(double limit)
		{
			return GetHeadPositions(limit, limit);
		}

		/// <summary>
		/// Gets an array of positions the head must move while looking for a human
		/// </summary>
		/// <param name="pan">Max angle to move in pan</param>
		/// <param name="tilt">Max angle to move in tilt</param>
		/// <returns>array of positions</returns>
		private double[,] GetHeadPositions(double pan, double tilt)
		{
			double[,] positions;

			//positions = new double[9, 2]
			positions = new double[6, 2]
			{
				{ 0,	0		}, // Center
				{ -pan,	0		}, // Center Left
				//{ -pan,	tilt	}, // Up Left
				//{ 0,		tilt	}, // Up Center
				//{ pan,	tilt	}, // Up Right
				{ pan,	0		}, // Center Right
				{ pan,	-tilt	}, // Down right
				{ 0,	-tilt	}, // Down center
				{ -pan,	-tilt	} // Down left
			};

			return positions;
		}

		#endregion
	}
}
