using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Robotics.API;
using Robotics.PacIto;

namespace ST_PLN
{
	/// <summary>
	///  Options for enrollment when received a Remember_Human Command
	/// </summary>
	public enum EnrollmentType
	{
		/// <summary>
		/// Enroll a human only once
		/// </summary>
		SingleEnroll,
		/// <summary>
		/// Enroll the human multiple times, asking him to show different emotions
		/// </summary>
		InteractiveEnroll,
		/// <summary>
		/// Enroll the human multiple times
		/// </summary>
		MultipleEnroll
	};

	/// <summary>
	/// Represents a CommandExecuter that executed the remember_human command
	/// </summary>
	public class RememberHumanCommandExecuter : AsyncCommandExecuter
	{
		#region Variables

		/// <summary>
		/// The type of enrollment used to enroll humans
		/// </summary>
		public EnrollmentType enrollmentType;

		/// <summary>
		/// The number of attemps for a multiple attempt enrollment
		/// </summary>
		private int multipleEnrollAttempts;

		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of RememberHumanCommandExecuter
		/// </summary>
		public RememberHumanCommandExecuter()
			: base("remember_human")
		{
			enrollmentType = EnrollmentType.InteractiveEnroll;
			multipleEnrollAttempts = 3;
		}

		#endregion

		#region Events
		#endregion

		#region Properties

		/// <summary>
		/// Gets the number of attemps used in a multiple-attempt enrollment
		/// </summary>
		public int MultipleEnrollAttempts
		{
			get { return multipleEnrollAttempts; }
			set
			{
				if ((value < 1) || (value > 10))
					throw new ArgumentOutOfRangeException();
				multipleEnrollAttempts = value;
			}
		}

		public new PacItoCommandManager CommandManager
		{
			get { return (PacItoCommandManager)base.CommandManager; }
		}

		/// <summary>
		/// Gets or sets the type of enrollment used to enroll humans
		/// </summary>
		public EnrollmentType EnrollmentType
		{
			get { return enrollmentType; }
			set
			{
				enrollmentType = value;
			}
		}

		#endregion

		#region Methodos

		protected override Response AsyncTask(Command command)
		{
			switch (enrollmentType)
			{
				case EnrollmentType.SingleEnroll:
					return RememberHuman(command);

				case EnrollmentType.InteractiveEnroll:
					return RememberHumanInteractive(command);

				case EnrollmentType.MultipleEnroll:
					return RememberHumanMultiple(command);

				default:
					return RememberHuman(command);
			}
		}

		public override void DefaultParameterParser(string[] parameters)
		{
			return;
		}

		/// <summary>
		/// Excecutes a remember_human procedure
		/// </summary>
		/// <param name="command">The command which contains the name of the person to remember out</param>
		private Response RememberHuman(Command command)
		{
			// 1. Send the pr_remember command
			if (!CommandManager.RobotPersonFinder.RememberHuman(command.Parameters))
			{
				Console("No human found");
				return Response.CreateFromCommand(command, false);
			}

			Console("Remember human ["+command.Parameters+"] Complete!");
			// 2. Update and send response
			return Response.CreateFromCommand(command, true);
		}

		/// <summary>
		/// Excecutes a interactive remember_human procedure which allows take different expressions of the same person
		/// </summary>
		/// <param name="command">The command which contains the name of the person to remember out</param>
		private Response RememberHumanInteractive(Command command)
		{
			// Stores global success answer
			bool success = false;

			// 1. First Training
			success = CommandManager.RobotPersonFinder.RememberHuman(command.Parameters);

			// 1.1 If firts training succeded, try to realize the other ones
			if (!success)
			{
				Console("No human found");
				return Response.CreateFromCommand(command, false);
			}

			// 2. Train face smiling
			// 2.1 Request Smile
			CommandManager.RobotSpeechGenerator.Say("Please, smile");
			// 2.2. 500ms human response
			Thread.Sleep(500);
			// 2.3. Second training
			success |= CommandManager.RobotPersonFinder.RememberHuman(command.Parameters);

			// 3 Train Serious face
			// 3.1. Request serious face
			CommandManager.RobotSpeechGenerator.Say("Now, a serious face");
			// 3.2 500ms human response
			Thread.Sleep(500);
			// 3.3. Second training
			success |= CommandManager.RobotPersonFinder.RememberHuman(command.Parameters);

			// 4. Update and send response
			Console("Remember human [" + command.Parameters + "] Complete!");
			return Response.CreateFromCommand(command, success);
		}

		/// <summary>
		/// Excecutes a remember_human procedure with multiple training
		/// </summary>
		/// <param name="command">The command which contains the name of the person to remember out</param>
		private Response RememberHumanMultiple(Command command)
		{
			// The number of succeded attempts
			int succededAttempts = 0;

			// 1. Try to enroll multiple times
			for (int count = 0; count < MultipleEnrollAttempts; ++count)
			{
				if (CommandManager.RobotPersonFinder.RememberHuman(command.Parameters))
					++succededAttempts;
			}

			return Response.CreateFromCommand(command, succededAttempts > 1);
		}

		#endregion
	}
}