using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Robotics.API;
using Robotics.PacIto;

namespace ST_PLN
{
	/// <summary>
	/// Represents a CommandExecuter that executed the find_object command
	/// </summary>
	public class FindObjectCommandExecuter : AsyncCommandExecuter
	{
		#region Variables
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of FindObjectCommandExecuter
		/// </summary>
		public FindObjectCommandExecuter()
			: base("find_object") { }

		#endregion

		#region Events
		#endregion

		#region Properties

		public new PacItoCommandManager CommandManager
		{
			get { return (PacItoCommandManager)base.CommandManager; }
		}

		#endregion

		#region Methodos

		protected override Response AsyncTask(Command command)
		{
			// Store head positions
			double[,] headPositions = GetHeadPositions(1, 0.7, 0.4);
			// Store robot turn angles
			double[] angles = new double[]
			{
				0.3926,		// Turn 22.5 degrees left.
				-0.7854		// Return to 0 and turn 22.5 degrees right
			};
			//Retrieve the human name
			string objectName = command.Parameters.Trim();
			// Head position index
			int hix = 0;
			// Robot angle index
			int raix = 0;
			// Flag that indicates if human has been found
			bool found = false;
			// flag that indicates error
			bool error = false;

			// From robot starting position
			Console("Executing find_object");
			do
			{
				// From head startup/last position
				hix = 0;
				do
				{
					// 1. Move the head to the next position (first position center the head).
					if (error &= !CommandManager.RobotHead.LookAt(ref headPositions[hix, 0], ref headPositions[hix, 1]))
					{
						++hix;
						// Stabilization time
						Thread.Sleep(10);
					}
					else break;

					// 2. Send the find human command and wait for response.
					if (found |= CommandManager.RobotObjectFinder.FindObject(ref objectName))
						break;

				} while (!found && !error && (hix < headPositions.GetLength(0)));
				if (found || error) break;

				// 3. Before turn, reset the face
				error &= !CommandManager.RobotHead.Show("normal");
				// 4. No human found. Moving robot to next angle
				error &= !CommandManager.RobotBase.MoveBase(0, angles[raix++], 5000);
				// 5. All head positions visited. Reset head counter
				hix = 0;

			} while (!found && !error && (raix < angles.Length));

			// 6. On error send failed response
			if (error)
			{
				Console("Error executing find_object");
				return Response.CreateFromCommand(command, false);
			}

			// 7. If no human found send failed response.
			if (!found)
			{
				Console("No object found");
				return Response.CreateFromCommand(command, false);
			}

			// 8. Update and send response
			command.Parameters = objectName;
			return Response.CreateFromCommand(command, true);
		}

		public override void DefaultParameterParser(string[] parameters)
		{
			return;
		}

		/// <summary>
		/// Gets an array of positions the head must move while looking for a human
		/// </summary>
		/// <param name="limit">Max angle to move</param>
		/// <returns>array of positions</returns>
		private double[,] GetHeadPositions(double limit)
		{
			return GetHeadPositions(limit, limit);
		}

		/// <summary>
		/// Gets an array of positions the head must move while looking for a human
		/// </summary>
		/// <param name="pan">Max angle to move in pan</param>
		/// <param name="tilt">Max angle to move in tilt</param>
		/// <returns>array of positions</returns>
		private double[,] GetHeadPositions(double pan, double tilt)
		{
			double[,] positions;

			//positions = new double[9, 2]
			positions = new double[6, 2]
			{
				{ 0,	0		}, // Center
				{ -pan,	0		}, // Center Left
				//{ -pan,	tilt	}, // Up Left
				//{ 0,		tilt	}, // Up Center
				//{ pan,	tilt	}, // Up Right
				{ pan,	0		}, // Center Right
				{ pan,	-tilt	}, // Down right
				{ 0,	-tilt	}, // Down center
				{ -pan,	-tilt	} // Down left
			};

			return positions;
		}

		/// <summary>
		/// Gets an array of positions the head must move while looking for a human
		/// </summary>
		/// <param name="neck">Max angle to move neck</param>
		/// <param name="pan">Max angle to move in pan</param>
		/// <param name="tilt">Max angle to move in tilt</param>
		/// <returns>array of positions</returns>
		/// <remarks>Neck steps are 0, -neck/2, -neck. Pan steps are -pan, 0, pan. Tilt steps are -tilt, 0</remarks>
		private double[,] GetHeadPositions(double neck, double pan, double tilt)
		{
			double[,] positions;
			double n2 = -neck / 2;
			
			//positions = new double[27, 3]
			positions = new double[18, 3]
			{
				// Neck position 0
				{ 0,		0,		0		}, // Center
				{ 0,		-pan,	0		}, // Center Left
				//{ 0,		-pan,	tilt	}, // Up Left
				//{ 0,		0,		tilt	}, // Up Center
				//{ 0,		pan,	tilt	}, // Up Right
				{ 0,		pan,	0		}, // Center Right
				{ 0,		pan,	-tilt	}, // Down right
				{ 0,		0,		-tilt	}, // Down center
				{ 0,		-pan,	-tilt	}, // Down left

				// Neck position 1
				{ n2,		0,		0		}, // Center
				{ n2,		-pan,	0		}, // Center Left
				//{ n2,		-pan,	tilt	}, // Up Left
				//{ n2,		0,		tilt	}, // Up Center
				//{ n2,		pan,	tilt	}, // Up Right
				{ n2,		pan,	0		}, // Center Right
				{ n2,		pan,	-tilt	}, // Down right
				{ n2,		0,		-tilt	}, // Down center
				{ n2,		-pan,	-tilt	}, // Down left

				// Neck position 1
				{ -neck,	0,		0		}, // Center
				{ -neck,	-pan,	0		}, // Center Left
				//{ -neck,	-pan,	tilt	}, // Up Left
				//{ -neck,	0,		tilt	}, // Up Center
				//{ -neck,	pan,	tilt	}, // Up Right
				{ -neck,	pan,	0		}, // Center Right
				{ -neck,	pan,	-tilt	}, // Down right
				{ -neck,	0,		-tilt	}, // Down center
				{ -neck,	-pan,	-tilt	} // Down left
			};

			return positions;
		}

		#endregion
	}
}
